#include <navilnux.h>

int main(void)
{
    while(1){
        printf("hello world\n");
        msleep(1000);
    }
    return 0;
}	
