#ifndef _NAVIL_USER
#define _NAVIL_USER

void user_task_1(void);
void user_task_2(void);
void user_task_3(void);


#endif
