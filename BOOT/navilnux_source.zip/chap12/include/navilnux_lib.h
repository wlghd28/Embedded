#ifndef _NAVIL_LIB
#define _NAVIL_LIB

extern int mysyscall(int, int, int);
extern int mysyscall4(int, int, int, int);

#endif
