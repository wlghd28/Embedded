#ifndef _NAVIL_SYS_TBL
#define _NAVIL_SYS_TBL

#define SYS_MYSYSCALL   0
#define SYS_MYSYSCALL4  1

#endif
